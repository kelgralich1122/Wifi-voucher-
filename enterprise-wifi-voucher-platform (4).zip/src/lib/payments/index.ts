export interface PaymentProvider {
  name: string;
  createOrder(amount: number, currency: string, metadata: any): Promise<any>;
  verifyPayment(transactionId: string): Promise<boolean>;
  handleWebhook(payload: any): Promise<void>;
}

export class StripeProvider implements PaymentProvider {
  name = "stripe";
  async createOrder(amount: number, currency: string, metadata: any) {
    return { id: "pi_" + Math.random().toString(36).substr(2, 9), url: "https://stripe.com/pay" };
  }
  async verifyPayment(transactionId: string) { return true; }
  async handleWebhook(payload: any) { console.log("Stripe Webhook", payload); }
}

export class MpesaProvider implements PaymentProvider {
  name = "mpesa";
  async createOrder(amount: number, currency: string, metadata: any) {
    return { checkoutRequestId: "req_" + Math.random().toString(36).substr(2, 9) };
  }
  async verifyPayment(transactionId: string) { return true; }
  async handleWebhook(payload: any) { console.log("M-Pesa Webhook", payload); }
}

export class PaymentFactory {
  static getProvider(gateway: string): PaymentProvider {
    switch (gateway) {
      case "stripe": return new StripeProvider();
      case "mpesa": return new MpesaProvider();
      default: throw new Error("Unsupported gateway");
    }
  }
}
