export interface RouterProvider {
  name: string;
  authenticate(credentials: any): Promise<boolean>;
  addVoucher(voucher: any): Promise<void>;
  removeVoucher(code: string): Promise<void>;
  getStatus(): Promise<"online" | "offline" | "error">;
  disconnectUser(macAddress: string): Promise<void>;
}

export class MikrotikProvider implements RouterProvider {
  name = "mikrotik";
  async authenticate(credentials: any) { return true; }
  async addVoucher(voucher: any) { console.log("MikroTik: Added voucher", voucher.code); }
  async removeVoucher(code: string) { console.log("MikroTik: Removed voucher", code); }
  async getStatus() { return "online" as const; }
  async disconnectUser(macAddress: string) { console.log("MikroTik: Disconnected user", macAddress); }
}

export class UnifiProvider implements RouterProvider {
  name = "unifi";
  async authenticate(credentials: any) { return true; }
  async addVoucher(voucher: any) { console.log("UniFi: Added voucher", voucher.code); }
  async removeVoucher(code: string) { console.log("UniFi: Removed voucher", code); }
  async getStatus() { return "online" as const; }
  async disconnectUser(macAddress: string) { console.log("UniFi: Disconnected user", macAddress); }
}

export class RouterFactory {
  static getProvider(type: string, config: any): RouterProvider {
    switch (type) {
      case "mikrotik": return new MikrotikProvider();
      case "unifi": return new UnifiProvider();
      // Add more providers here
      default: return new MikrotikProvider(); // Fallback
    }
  }
}
