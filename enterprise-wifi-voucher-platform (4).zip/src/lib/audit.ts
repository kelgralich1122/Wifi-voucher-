import { db } from "@/db";
import { auditLogs } from "@/db/schema";

export async function logAction(params: {
  userId: string;
  action: string;
  resource: string;
  details?: any;
  ipAddress?: string;
}) {
  try {
    await db.insert(auditLogs).values({
      userId: params.userId,
      action: params.action,
      resource: params.resource,
      details: params.details || {},
      ipAddress: params.ipAddress,
    });
  } catch (error) {
    console.error("Failed to log action:", error);
  }
}
