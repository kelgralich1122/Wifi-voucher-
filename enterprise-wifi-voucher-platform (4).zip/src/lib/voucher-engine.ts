import { nanoid } from "nanoid";
import { db } from "@/db";
import { vouchers, packages } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export class VoucherEngine {
  static generateCode(length = 8) {
    // Generate an easy-to-read code (no O, 0, I, 1)
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < length; i++) {
      code += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    return code;
  }

  static async bulkGenerate(params: {
    packageId: string;
    companyId: string;
    branchId?: string;
    userId: string;
    count: number;
    codeLength?: number;
  }) {
    const { packageId, companyId, branchId, userId, count, codeLength } = params;

    const pkg = await db.query.packages.findFirst({
      where: eq(packages.id, packageId),
    });

    if (!pkg) throw new Error("Package not found");

    const newVouchers = [];
    for (let i = 0; i < count; i++) {
      newVouchers.push({
        code: this.generateCode(codeLength),
        packageId,
        companyId,
        branchId,
        userId,
        status: "active" as const,
        remainingData: pkg.dataLimitBytes,
      });
    }

    return await db.insert(vouchers).values(newVouchers).returning();
  }

  static async activateVoucher(code: string) {
    const voucher = await db.query.vouchers.findFirst({
      where: eq(vouchers.code, code),
      with: { package: true },
    });

    if (!voucher) throw new Error("Voucher not found");
    if (voucher.status !== "active") throw new Error("Voucher already used or inactive");

    const activatedAt = new Date();
    let expiresAt = null;

    if (voucher.package.validitySeconds) {
      expiresAt = new Date(activatedAt.getTime() + voucher.package.validitySeconds * 1000);
    }

    const [updated] = await db.update(vouchers)
      .set({
        status: "used",
        activatedAt,
        expiresAt,
        usedAt: activatedAt,
      })
      .where(eq(vouchers.id, voucher.id))
      .returning();

    return updated;
  }
}
