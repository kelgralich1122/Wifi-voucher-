"use client";

import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent, Button, Input } from "@/components/ui";
import { Ticket, QrCode, Globe } from "lucide-react";

export default function CaptivePortal({ params }: { params: { slug: string } }) {
  const [voucherCode, setVoucherCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/portal/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: voucherCode, companySlug: params.slug }),
      });

      if (res.ok) {
        setSuccess(true);
        // In a real scenario, we'd redirect to the router's success URL
        setTimeout(() => {
          window.location.href = "https://google.com";
        }, 3000);
      } else {
        const data = await res.json();
        setError(data.error || "Invalid voucher code");
      }
    } catch (err) {
      setError("An error occurred");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-blue-600 p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-10 pb-10">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Globe size={40} />
            </div>
            <h2 className="text-2xl font-bold mb-2">Connected!</h2>
            <p className="text-slate-500">You are now connected to the internet.</p>
            <p className="text-xs text-slate-400 mt-4 italic">Redirecting you to Google...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 p-4">
      <div className="mb-8 text-center">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-4 shadow-lg">
          <Globe size={32} />
        </div>
        <h1 className="text-2xl font-bold text-slate-900">Enterprise Guest WiFi</h1>
        <p className="text-slate-500">Welcome! Please enter your voucher code to connect.</p>
      </div>

      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex border-b border-slate-100 -mx-6 -mt-6">
            <button className="flex-1 py-4 text-sm font-bold border-b-2 border-blue-600 text-blue-600">
              VOUCHER LOGIN
            </button>
            <button className="flex-1 py-4 text-sm font-medium text-slate-400 hover:text-slate-600">
              SOCIAL LOGIN
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4 pt-4">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Voucher Code</label>
              <div className="relative">
                <Ticket className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <Input
                  className="pl-10 h-12 text-lg font-mono uppercase tracking-widest"
                  placeholder="XXXX-XXXX"
                  value={voucherCode}
                  onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                  required
                />
              </div>
            </div>
            {error && <p className="text-sm text-red-500 text-center">{error}</p>}
            <Button type="submit" className="w-full h-12 text-lg font-bold" disabled={loading}>
              {loading ? "Verifying..." : "Connect Now"}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-xs text-slate-400 mb-4 uppercase tracking-widest font-bold">Or use QR Code</p>
            <button className="p-4 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors">
              <QrCode size={48} className="text-slate-600" />
            </button>
          </div>
        </CardContent>
      </Card>

      <div className="mt-8 text-slate-400 text-xs flex items-center gap-4">
        <a href="#" className="hover:text-slate-600">Terms of Service</a>
        <span>•</span>
        <a href="#" className="hover:text-slate-600">Privacy Policy</a>
        <span>•</span>
        <a href="#" className="hover:text-slate-600">Support</a>
      </div>
    </div>
  );
}
