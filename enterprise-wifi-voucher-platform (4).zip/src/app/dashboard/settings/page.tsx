import { db } from "@/db";
import { companies } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Card, CardHeader, CardTitle, CardContent, Button, Input } from "@/components/ui";
import { eq } from "drizzle-orm";

export default async function SettingsPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const company = await db.query.companies.findFirst({
    where: eq(companies.id, session.user.companyId),
  });

  return (
    <div className="max-w-4xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-slate-500 text-sm">Manage your company profile and platform configurations.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Company Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Company Name</label>
                <Input defaultValue={company?.name} />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Company Slug</label>
                <Input defaultValue={company?.slug} disabled />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Contact Email</label>
              <Input defaultValue={company?.contactEmail || ""} />
            </div>
            <Button>Save Changes</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Branding</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Primary Color</label>
                <div className="flex gap-2">
                  <Input type="color" className="w-12 h-10 p-1" defaultValue={(company?.branding as any)?.primaryColor || "#3b82f6"} />
                  <Input defaultValue={(company?.branding as any)?.primaryColor || "#3b82f6"} />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Secondary Color</label>
                <div className="flex gap-2">
                  <Input type="color" className="w-12 h-10 p-1" defaultValue={(company?.branding as any)?.secondaryColor || "#1e293b"} />
                  <Input defaultValue={(company?.branding as any)?.secondaryColor || "#1e293b"} />
                </div>
              </div>
            </div>
            <div className="border border-slate-200 rounded-lg p-6 bg-slate-50 flex flex-col items-center justify-center text-center">
              <p className="text-xs font-bold text-slate-400 uppercase mb-4 tracking-widest">Preview</p>
              <div className="w-full bg-white rounded shadow-sm overflow-hidden max-w-[200px]">
                <div className="h-2 bg-blue-600"></div>
                <div className="p-4 space-y-2">
                  <div className="h-3 w-3/4 bg-slate-200 rounded"></div>
                  <div className="h-8 w-full bg-blue-600 rounded"></div>
                </div>
              </div>
            </div>
          </div>
          <Button className="mt-6">Update Branding</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-red-600">Danger Zone</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Maintenance Mode</p>
              <p className="text-sm text-slate-500">Temporarily disable the captive portal for users.</p>
            </div>
            <Button variant="outline" className="text-red-600 hover:bg-red-50 hover:text-red-700">Enable</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
