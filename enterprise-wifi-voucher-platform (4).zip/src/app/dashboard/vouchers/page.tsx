import { db } from "@/db";
import { vouchers, packages } from "@/db/schema";
import { desc } from "drizzle-orm";
import { Card, CardHeader, CardTitle, CardContent, Button } from "@/components/ui";
import { Plus, Download, Printer } from "lucide-react";
import Link from "next/link";

export default async function VouchersPage() {
  const allVouchers = await db.query.vouchers.findMany({
    with: {
      package: true,
    },
    orderBy: [desc(vouchers.createdAt)],
    limit: 50,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Vouchers</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Printer size={16} /> Print Bulk
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download size={16} /> Export
          </Button>
          <Link href="/dashboard/vouchers/new">
            <Button className="flex items-center gap-2">
              <Plus size={16} /> Generate Vouchers
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase text-xs font-medium">
                <tr>
                  <th className="px-6 py-4">Code</th>
                  <th className="px-6 py-4">Package</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Activated At</th>
                  <th className="px-6 py-4">Expires At</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {allVouchers.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-mono font-bold text-blue-600">{v.code}</td>
                    <td className="px-6 py-4">{v.package?.name}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-full text-[10px] font-bold uppercase",
                        v.status === 'active' ? "bg-green-100 text-green-700" :
                        v.status === 'used' ? "bg-blue-100 text-blue-700" :
                        "bg-slate-100 text-slate-700"
                      )}>
                        {v.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-slate-500">
                      {v.activatedAt ? new Date(v.activatedAt).toLocaleString() : '-'}
                    </td>
                    <td className="px-6 py-4 text-slate-500">
                      {v.expiresAt ? new Date(v.expiresAt).toLocaleString() : '-'}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Button variant="ghost" size="sm">Details</Button>
                    </td>
                  </tr>
                ))}
                {allVouchers.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-10 text-center text-slate-400 italic">
                      No vouchers found. Click "Generate Vouchers" to create some.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Utility to handle class merging in this file since I don't have it imported globally in this block
function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(" ");
}
