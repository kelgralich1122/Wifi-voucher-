import { db } from "@/db";
import { packages } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import GenerateVoucherForm from "./generate-form";

export default async function NewVouchersPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const availablePackages = await db.query.packages.findMany({
    where: (pkgs, { eq }) => eq(pkgs.isActive, true),
  });

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Generate Vouchers</h1>
      <GenerateVoucherForm 
        packages={availablePackages} 
        userId={session.user.id} 
        companyId={session.user.companyId} 
      />
    </div>
  );
}
