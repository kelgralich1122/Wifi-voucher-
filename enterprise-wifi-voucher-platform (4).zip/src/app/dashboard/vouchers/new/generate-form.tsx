"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, Button, Input } from "@/components/ui";

export default function GenerateVoucherForm({ packages, userId, companyId }: any) {
  const [loading, setLoading] = useState(false);
  const [pkgId, setPkgId] = useState("");
  const [count, setCount] = useState(10);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch("/api/vouchers/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ packageId: pkgId, count, userId, companyId }),
      });

      if (res.ok) {
        router.push("/dashboard/vouchers");
        router.refresh();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Package</label>
            <select
              className="w-full h-10 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={pkgId}
              onChange={(e) => setPkgId(e.target.value)}
              required
            >
              <option value="">Choose a package...</option>
              {packages.map((p: any) => (
                <option key={p.id} value={p.id}>
                  {p.name} - ${p.price}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Quantity to Generate</label>
            <Input
              type="number"
              min="1"
              max="1000"
              value={count}
              onChange={(e) => setCount(parseInt(e.target.value))}
              required
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || !pkgId}>
              {loading ? "Generating..." : "Generate Vouchers"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
