import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Globe, Shield, Zap } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui";

export default async function Home() {
  const session = await getSession();

  if (session) {
    redirect("/dashboard");
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="border-b border-slate-100 py-6 px-8 flex items-center justify-between">
        <div className="flex items-center gap-2 font-bold text-xl">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white text-xs">WIFI</div>
          NetManager
        </div>
        <div className="flex gap-4">
          <Link href="/login">
            <Button variant="ghost">Sign In</Button>
          </Link>
          <Button>Start Free Trial</Button>
        </div>
      </header>

      <main>
        <section className="py-24 px-8 text-center max-w-4xl mx-auto">
          <h1 className="text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
            Enterprise WiFi <span className="text-blue-600">Voucher Management</span> for Scalable Networks
          </h1>
          <p className="text-xl text-slate-500 mb-10 leading-relaxed">
            The all-in-one platform for ISPs, Hotels, and Cafés to manage hotspots, generate vouchers, and track revenue in real-time.
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/login">
              <Button size="lg" className="px-10 h-14 text-lg">Launch Dashboard</Button>
            </Link>
            <Button size="lg" variant="outline" className="px-10 h-14 text-lg">View Demo</Button>
          </div>
        </section>

        <section className="py-20 bg-slate-50 border-y border-slate-100">
          <div className="max-w-6xl mx-auto px-8 grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
                <Shield size={24} />
              </div>
              <h3 className="text-xl font-bold">Secure Auth</h3>
              <p className="text-slate-500">RADIUS-compatible authentication with per-device limits and session control.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
                <Zap size={24} />
              </div>
              <h3 className="text-xl font-bold">Voucher Engine</h3>
              <p className="text-slate-500">Bulk generate QR-coded vouchers with custom time and data limits instantly.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
                <Globe size={24} />
              </div>
              <h3 className="text-xl font-bold">Multi-Tenant</h3>
              <p className="text-slate-500">Manage multiple branches, companies, and routers from a single centralized dashboard.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-12 border-t border-slate-100 text-center text-slate-400 text-sm">
        © 2026 NetManager Enterprise WiFi. All rights reserved.
      </footer>
    </div>
  );
}
