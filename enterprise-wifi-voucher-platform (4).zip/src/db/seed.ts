import { db } from "./index";
import { users, companies, packages } from "./schema";
import bcrypt from "bcryptjs";

async function seed() {
  console.log("Seeding database...");

  // Create default company
  const [company] = await db.insert(companies).values({
    name: "Enterprise WiFi Ltd",
    slug: "enterprise-wifi",
    branding: {
      primaryColor: "#3b82f6",
      secondaryColor: "#1e293b",
    },
  }).returning();

  const hashedPassword = await bcrypt.hash("admin123", 10);

  // Create super admin
  const [admin] = await db.insert(users).values({
    email: "admin@example.com",
    password: hashedPassword,
    name: "Super Admin",
    role: "super_admin",
    companyId: company.id,
  }).returning();

  // Create some default packages
  await db.insert(packages).values([
    {
      companyId: company.id,
      name: "1 Hour Fast",
      type: "time",
      price: "1.00",
      validitySeconds: 3600,
      description: "High speed internet for 1 hour.",
    },
    {
      companyId: company.id,
      name: "1GB Daily",
      type: "data",
      price: "5.00",
      validitySeconds: 86400,
      dataLimitBytes: "1073741824",
      description: "1GB of data valid for 24 hours.",
    },
    {
      companyId: company.id,
      name: "Monthly Unlimited",
      type: "unlimited",
      price: "50.00",
      validitySeconds: 2592000,
      description: "Unlimited high-speed internet for 30 days.",
    }
  ]);

  console.log("Seeding completed.");
}

seed().catch(console.error);
