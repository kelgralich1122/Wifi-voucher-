import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  boolean,
  decimal,
  uuid,
  varchar,
  jsonb,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").unique().notNull(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role", { enum: ["super_admin", "company_admin", "reseller", "operator"] }).notNull().default("operator"),
  companyId: uuid("company_id"),
  branchId: uuid("branch_id"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const companies = pgTable("companies", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  slug: text("slug").unique().notNull(),
  logo: text("logo"),
  branding: jsonb("branding").default({
    primaryColor: "#3b82f6",
    secondaryColor: "#1e293b",
  }),
  address: text("address"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const branches = pgTable("branches", {
  id: uuid("id").primaryKey().defaultRandom(),
  companyId: uuid("company_id").references(() => companies.id).notNull(),
  name: text("name").notNull(),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const packages = pgTable("packages", {
  id: uuid("id").primaryKey().defaultRandom(),
  companyId: uuid("company_id").references(() => companies.id),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type", { enum: ["time", "data", "unlimited"] }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  validitySeconds: integer("validity_seconds"), // Time limit
  dataLimitBytes: decimal("data_limit_bytes", { precision: 20, scale: 0 }), // Data limit
  deviceLimit: integer("device_limit").default(1),
  speedLimitUp: integer("speed_limit_up"), // kbps
  speedLimitDown: integer("speed_limit_down"), // kbps
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vouchers = pgTable("vouchers", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: varchar("code", { length: 20 }).unique().notNull(),
  packageId: uuid("package_id").references(() => packages.id).notNull(),
  companyId: uuid("company_id").references(() => companies.id).notNull(),
  branchId: uuid("branch_id").references(() => branches.id),
  userId: uuid("user_id").references(() => users.id), // Operator who created it
  status: text("status", { enum: ["active", "used", "expired", "paused", "disabled"] }).default("active"),
  usedAt: timestamp("used_at"),
  activatedAt: timestamp("activated_at"),
  expiresAt: timestamp("expires_at"),
  remainingData: decimal("remaining_data", { precision: 20, scale: 0 }),
  totalDataUsed: decimal("total_data_used", { precision: 20, scale: 0 }).default("0"),
  totalTimeUsed: integer("total_time_used").default(0), // in seconds
  createdAt: timestamp("created_at").defaultNow(),
});

export const routers = pgTable("routers", {
  id: uuid("id").primaryKey().defaultRandom(),
  companyId: uuid("company_id").references(() => companies.id).notNull(),
  branchId: uuid("branch_id").references(() => branches.id),
  name: text("name").notNull(),
  type: text("type", { enum: ["mikrotik", "unifi", "tplink", "openwrt", "cisco", "aruba", "cambium"] }).notNull(),
  ipAddress: text("ip_address"),
  macAddress: text("mac_address"),
  secretKey: text("secret_key"),
  config: jsonb("config"),
  status: text("status", { enum: ["online", "offline", "error"] }).default("offline"),
  lastSeen: timestamp("last_seen"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  companyId: uuid("company_id").references(() => companies.id).notNull(),
  userId: uuid("user_id").references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD"),
  gateway: text("gateway").notNull(), // stripe, mpesa, etc.
  transactionId: text("transaction_id").unique(),
  status: text("status", { enum: ["pending", "completed", "failed", "refunded"] }).default("pending"),
  voucherId: uuid("voucher_id").references(() => vouchers.id),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => users.id),
  action: text("action").notNull(),
  resource: text("resource").notNull(),
  details: jsonb("details"),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").unique().notNull(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const userRelations = relations(users, ({ one, many }) => ({
  company: one(companies, { fields: [users.companyId], references: [companies.id] }),
  branch: one(branches, { fields: [users.branchId], references: [branches.id] }),
  auditLogs: many(auditLogs),
}));

export const companyRelations = relations(companies, ({ many }) => ({
  branches: many(branches),
  users: many(users),
  packages: many(packages),
  vouchers: many(vouchers),
  routers: many(routers),
}));

export const voucherRelations = relations(vouchers, ({ one }) => ({
  package: one(packages, { fields: [vouchers.packageId], references: [packages.id] }),
  company: one(companies, { fields: [vouchers.companyId], references: [companies.id] }),
  branch: one(branches, { fields: [vouchers.branchId], references: [branches.id] }),
}));
